default['demo2']['NAME']='DEMO2 from Cookbook'
