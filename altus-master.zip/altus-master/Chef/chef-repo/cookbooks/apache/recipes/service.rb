service "httpd" do
  action [:restart, :enable]
end