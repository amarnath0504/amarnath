#
# Cookbook:: demo1
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

puts 'Hello from demo1'
