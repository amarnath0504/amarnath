default['mariadb']['dbuser']='student'
default['mariadb']['dbpass']='student@1'
default['mariadb']['tomcatip']='localhost'