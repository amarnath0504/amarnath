name 'prod'
description 'The production environment'
cookbook_versions  'demo2' => '= 0.1.1'
