x=1
y=1+x
puts x
