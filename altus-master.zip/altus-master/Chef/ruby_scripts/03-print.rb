x=1
puts "Value of x = #{x}"
