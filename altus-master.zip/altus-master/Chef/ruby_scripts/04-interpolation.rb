h = {
  'first_name' => 'Bob',
  'last_name'  => 'Jones'
}

puts "First Name = #{h['first_name']}"
