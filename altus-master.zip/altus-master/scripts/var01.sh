#!/bin/bash

## Define a variable
NAME=Rahim

echo "Hello $NAME"
echo "$NAME, Good Morning"
echo "$NAME, You are attending DevOps Class"
