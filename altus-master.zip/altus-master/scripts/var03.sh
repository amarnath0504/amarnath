#!/bin/bash

DATE=$(date  +%F)
echo "Hello, Good Morning"
echo "Today date is $DATE"