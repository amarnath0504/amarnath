#!/bin/bash

## Variable from ENV


echo "Welcome $USER"
echo "Number of Apples = $APPLES"