#!/bin/bash

## Printsome colors
# Red	- 31	-> \e[31m
# Green	- 32 	
# Yellow	- 33
# Blue	- 34
# Magenta - 35
# Cyan	- 36


echo -e "\e[31mHello World\e[0m"
echo -e "\e[32mHello World\e[0m"
echo -e "\e[33mHello World\e[0m"
echo -e "\e[34mHello World\e[0m"
echo -e "\e[35mHello World\e[0m"
echo -e "\e[36mHello World\e[0m"
echo Welcome to DevOps Course