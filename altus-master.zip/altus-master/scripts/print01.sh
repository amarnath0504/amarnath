#!/bin/bash

### Script to print some output

echo Hello World
echo Welcome to DevOps Class


# print multiple lines

echo -e "Hello World\nWelcome to DevOps Class"

# print some tab space.

echo -e "One\tTwo\tThree"