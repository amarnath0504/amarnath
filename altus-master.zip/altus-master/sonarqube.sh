curl -s https://raw.githubusercontent.com/linuxautomations/sonarqube/master/install.sh | sudo bash
