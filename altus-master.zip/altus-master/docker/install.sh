curl -s https://raw.githubusercontent.com/linuxautomations/docker/master/install-ce.sh | bash
